void	ft_bzero(void *ptr, size_t len)
{
	ft_memset(ptr, 0, len);
}
